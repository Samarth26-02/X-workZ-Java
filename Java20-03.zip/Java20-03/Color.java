public enum Color {
    RED,BLUE,BLACK,YELLOW,GREEN;
}
