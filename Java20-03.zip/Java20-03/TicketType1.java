public enum TicketType1 {
    VIP,REGULAR,STUDENT
}
